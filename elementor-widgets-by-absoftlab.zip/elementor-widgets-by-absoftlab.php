<?php
/**
 * Plugin Name: Elementor Widgets by absoftlab
 * Description: A collection of custom Elementor widgets by absoftlab — includes Info Card, Team Card, Image Overlay Card and Review Slider.
 * Plugin URI:  https://absoftlab.com/elementor-widgets-by-absoftlab
 * Author:      absoftlab
 * Author URI:  https://absoftlab.com
 * Version:     1.3.3
 * Text Domain: absl-ew
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Basic constants
 */
define( 'ABSL_EW_VERSION', '1.3.3' );
define( 'ABSL_EW_URL', plugin_dir_url( __FILE__ ) );
define( 'ABSL_EW_PATH', plugin_dir_path( __FILE__ ) );

/**
 * ✅ Check Elementor dependency
 */
function absl_ew_elementor_loaded() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        add_action( 'admin_notices', function () {
            echo '<div class="notice notice-error"><p><strong>Elementor Widgets by absoftlab</strong> requires Elementor to be active.</p></div>';
        } );
        return false;
    }
    return true;
}

/**
 * ✅ Register custom category (ABSOFTLAB Widgets)
 */
add_action( 'elementor/elements/categories_registered', function ( $elements_manager ) {
    $elements_manager->add_category(
        'absoftlab',
        [
            'title' => __( 'ABSOFTLAB Widgets', 'absl-ew' ),
            'icon'  => 'fa fa-plug',
        ]
    );
} );

/**
 * ✅ Frontend assets (Swiper + Review Slider CSS/JS)
 *
 * এগুলো সব পেজেই লোড হবে – তাই হোম ছাড়া অন্য পেজেও স্লাইডার কাজ করবে।
 */
function absl_ew_enqueue_assets() {

    // Only frontend
    if ( is_admin() ) {
        return;
    }

    // Swiper CSS & JS (CDN)
    wp_register_style(
        'absl-ew-swiper',
        'https://unpkg.com/swiper@9/swiper-bundle.min.css',
        [],
        '9.4.1'
    );

    wp_register_script(
        'absl-ew-swiper',
        'https://unpkg.com/swiper@9/swiper-bundle.min.js',
        [ 'jquery' ],
        '9.4.1',
        true
    );

    // Our Review Slider CSS & JS
    wp_register_style(
        'absl-ew-review-slider',
        ABSL_EW_URL . 'assets/css/absl-review-slider.css',
        [],
        ABSL_EW_VERSION
    );

    wp_register_script(
        'absl-ew-review-slider',
        ABSL_EW_URL . 'assets/js/absl-review-slider.js',
        [ 'jquery', 'absl-ew-swiper' ],
        ABSL_EW_VERSION,
        true
    );

    // Enqueue globally on frontend so every page gets slider assets
    wp_enqueue_style( 'absl-ew-swiper' );
    wp_enqueue_style( 'absl-ew-review-slider' );
    wp_enqueue_script( 'absl-ew-swiper' );
    wp_enqueue_script( 'absl-ew-review-slider' );
}
add_action( 'wp_enqueue_scripts', 'absl_ew_enqueue_assets' );

/**
 * ✅ Register widgets
 */
function absl_ew_register_widgets( $widgets_manager ) {

    if ( ! absl_ew_elementor_loaded() ) {
        return;
    }

    // Widget files
    require_once ABSL_EW_PATH . 'widgets/info-card-widget.php';
    require_once ABSL_EW_PATH . 'widgets/image-overlay-card-widget.php';
    require_once ABSL_EW_PATH . 'widgets/team-card-widget.php';
    require_once ABSL_EW_PATH . 'widgets/review-slider-widget.php';

    // Register
    $widgets_manager->register( new \ABSL_Info_Card_Widget() );
    $widgets_manager->register( new \ABSL_Image_Overlay_Card_Widget() );
    $widgets_manager->register( new \ABSL_Team_Card_Widget() );
    $widgets_manager->register( new \ABSL_Review_Slider_Widget() );
}
add_action( 'elementor/widgets/register', 'absl_ew_register_widgets' );

/**
 * ✅ Initialize after Elementor loads
 */
function absl_ew_init() {
    absl_ew_elementor_loaded();
}
add_action( 'plugins_loaded', 'absl_ew_init' );
