jQuery(document).ready(function ($) {

    const sliders = document.querySelectorAll('.absl-review-slider');

    sliders.forEach(function (slider) {

        let swiperContainer = slider.querySelector('.swiper');
        if (!swiperContainer) return;

        new Swiper(swiperContainer, {
            loop: true,
            spaceBetween: 30,
            slidesPerView: 1,
            autoHeight: true,

            navigation: {
                nextEl: slider.querySelector('.swiper-button-next'),
                prevEl: slider.querySelector('.swiper-button-prev'),
            },

            pagination: {
                el: slider.querySelector('.swiper-pagination'),
                clickable: true,
            },
        });

    });

});
